<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="with=device=width, imitial-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <title>Psd to html</title>

    <!--google font-->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bandom/grid.css">
	
    <!--END font normalize bandom css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header id="home">
        <nav id="mainNav">
            <div class="row">
                <a href="#home" class="logo">
                    <img src="image/logo.png" alt="Cuda">
                </a>
                <div class="mobile-menu">
                    <span class="fa fa-bars" onclick="openNav()"></span>
                    <div id="myNav" class="myNav">
                        <a href="javascript:void(0)" class="close" onclick="closeNav()">&times;</a>
                        <div class="overlay_content">
                            <a onclick="closeNav()" href="#home">HOME</a>
                            <a onclick="closeNav()" href="#services">SERVICES</a>
                            <a onclick="closeNav()" href="#team">team</a>
                            <a onclick="closeNav()" href="#skil">Skil</a>
                            <a onclick="closeNav()" href="#port">BLOG</a>
                            <a onclick="closeNav()" href="#contact">CONTACT</a>
                        </div>
                    </div>
                </div>
                <ul class="main-nav">
                    <li><a class="active" href="#home">HOME</a></li>
                    <li><a href="#services">SERVICES</a></li>
                    <li><a href="#team">team</a></li>
                    <li><a href="#skil">Skil</a></li>
                    <li><a href="#port">BLOG</a></li>
                    <li><a href="#contact">CONTACT</a></li>
                </ul>
            </div>
        </nav>
        <div class="row">
            <div class="hero-text">
                <h1>Hi there! We are the new kids on the block and we build awesome websites and mobile apps.</h1>
                <a href="#" class="btn-hero">WORK WITH US!</a>
            </div>
        </div>
    </header>
    <section class="service-section js-section" id="services">
        <div class="row">
            <h2>SERVICES WE PROVIDE</h2>
            <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae, dignissimos!</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="image/icon/Cuda%20Single%20.png" alt="flag" class="service_icon">
                <h3>Branding</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, dolor.</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/icon/Cuda%20Single%20Page%20Portfolio%20copy.png" alt="flag" class="service_icon">
                <h3>Design</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, dolor.</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/icon/Single%20Page%20Portfolio%20copy.png" alt="flag" class="service_icon">
                <h3>Development</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, dolor.</p>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/icon/Cuda%20Page%20Portfolio%20copy.png" alt="flag" class="service_icon">
                <h3>Rocket Science</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, dolor.</p>
            </div>
        </div>
    </section>
    <section class="team-section" id="team">
        <div class="row">
            <h2>MEET OUR BEAUTIFUL TEAM</h2>
            <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur, cumque.</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box">
                <img src="image/First.jpg" alt="team" class="team-member">
                <h3>Ariyan</h3>
                <span class="role">CEO / Marketing Guru</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima delectus non, suscipit.</p>
                <div class="social-link">
                    <ul>
                        <li><a href="https//m.facemook.com"><i class="fab fa-facebook-square"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-skype"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/two.jpg" alt="team" class="team-member">
                <h3>Ariyan</h3>
                <span class="role">CEO / Marketing Guru</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima delectus non, suscipit.</p>
                <div class="social-link">
                    <ul>
                        <li><a href="https//m.facemook.com"><i class="fab fa-facebook-square"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-skype"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/3.jpg" alt="team" class="team-member">
                <h3>Ariyan</h3>
                <span class="role">CEO / Marketing Guru</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima delectus non, suscipit.</p>
                <div class="social-link">
                    <ul>
                        <li><a href="https//m.facemook.com"><i class="fab fa-facebook-square"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-skype"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="col span_1_of_4 box">
                <img src="image/there.jpg" alt="team" class="team-member">
                <h3>Ariyan</h3>
                <span class="role">CEO / Marketing Guru</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima delectus non, suscipit.</p>
                <div class="social-link">
                    <ul>
                        <li><a href="https//m.facemook.com"><i class="fab fa-facebook-square"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-skype"></i></a></li>
                        <li><a href="https//m.facemook.com"><i class="fab fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section class="skil-section" id="skil">
        <div class="row">
            <h2>ME GOT Skil</h2>
            <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae asperiores.</p>
        </div>
        <div class="row">
            <div class="col span_1_of_4 box web-design">
                <svg class="radial-progress" data-percentage="80" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">80%</text>
                </svg>
                <h3>WEB DESIGN</h3>
            </div>
            <div class="col span_1_of_4 box html-css">
                <svg class="radial-progress" data-percentage="90" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                </svg>
                <h3>HTML / CSS</h3>
            </div>
            <div class="col span_1_of_4 box graphic-design">
                <svg class="radial-progress" data-percentage="75" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                </svg>
                <h3>GRAPHIC DESIGN</h3>
            </div>
            <div class="col span_1_of_4 box web-devlopment">
                <svg class="radial-progress" data-percentage="20" viewBox="0 0 80 80">
                    <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                    <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                    <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">20%</text>
                </svg>
                <h3>WEB DEVLOPMENT</h3>
            </div>
        </div>
    </section>
    <section class="portfolio-section" id="port">
        <div class="row">
            <h2>OUR PROTFOLIO</h2>
            <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque possimus reprehenderit, illum, animi sunt dolores fugiat quasi! Quaerat, asperiores, illum.</p>
        </div>
        <div class="row">
            <div class="filter">
                <button type="button" data-filter="all">all</button>
                <button type="button" data-filter=".web">web</button>
                <button type="button" data-filter=".apps">apps</button>
                <button type="button" data-filter=".icon">icon</button>
            </div>
        </div>
        <div class="row container">
            <div class="col span_1_of_2 mix apps web box">
                <img src="image/protfo/1.png" alt="protfo" class="protfo_image">
                <h4>Lorem ipsum dolor sit amet.</h4>
            </div>
            <div class="col span_1_of_2 mix icon box">
                <img src="image/protfo/2.png" alt="protfo" class="protfo_image">
                <h4>Lorem ipsum dolor sit amet.</h4>
            </div>
            <div class="col span_1_of_2 mix web icon box">
                <img src="image/protfo/3.png" alt="protfo" class="protfo_image">
                <h4>Lorem ipsum dolor sit amet.</h4>
            </div>
            <div class="col span_1_of_2 mix apps web icon box">
                <img src="image/protfo/4.png" alt="protfo" class="protfo_image">
                <h4>Lorem ipsum dolor sit amet.</h4>
            </div>

        </div>
    </section>
    <section class="testimonial" id="test">
        <div class="row">
            <h2>What poeple say about us</h2>
            <p class="littel_description">our clients love us</p>
        </div>
        <div class="row">
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="image/First.jpg" alt="photo">
                </div>
                <div class="review">
                    <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat similique.</p>
                    <h3>chanel Imam</h3>
                    <span class="role">CEO of prienter</span>
                </div>
            </div>

            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="image/3.jpg" alt="photo">
                </div>
                <div class="review">
                    <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat similique.</p>
                    <h3>chanel Imam</h3>
                    <span class="role">CEO of prienter</span>
                </div>
            </div>


            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="image/3.jpg" alt="photo">
                </div>
                <div class="review">
                    <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat similique.</p>
                    <h3>chanel Imam</h3>
                    <span class="role">CEO of prienter</span>
                </div>
            </div>
            <div class="col span_1_of_2 box">
                <div class="client-photo">
                    <img src="image/there.jpg" alt="photo">
                </div>
                <div class="review">
                    <p class="littel_description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat similique.</p>
                    <h3>chanel Imam</h3>
                    <span class="role">CEO of prienter</span>
                </div>
            </div>
        </div>
    </section>
    <section class="contact-area" id="contact">
        <div class="row">
            <h2>get in touch</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio voluptate consequuntur, voluptatum ipsa assumenda qui.</p>
        </div>
        <div class="row">
            <form action="#" method="post">
                <div class="row">
                    <div class="col span_1_of_2">
                        <input type="text" name="name" placeholder="Your Name *" required>
                    </div>
                    <div class="col span_1_of_2">
                        <input type="Email" placeholder="Your Email *" required>
                    </div>
                </div>
                <div class="row">
                    <textarea name="" id="" cols="30" rows="10" placeholder="Your massage *" required></textarea>
                </div>
                <div class="row">
                    <input type="submit" value="SENT MASSAGE" class="btn btn-submit">
                </div>
            </form>
        </div>
    </section>
    <footer class="footer-section" id="footerContact">
        <div class="row">
            <ul>
                <li><a href="#">facebook</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">google+</a></li>
                <li><a href="#">Linkdin</a></li>
                <li><a href="#">Behance</a></li>
                <li><a href="#">Dribble</a></li>
                <li><a href="#">Github</a></li>
            </ul>
        </div>
    </footer>
    <!--js script-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/selectivizr-min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
